//
//  RNBO_PatcherFactory.cpp
//
//  Created by DDZ on 11/08/15.
//
//

#ifndef USE_DYNAMIC_COMPILATION

#ifdef RNBO_TEST_FILE
// this includes the test file directly when we are not using dynamic compilation

#include RNBO_TEST_FILE

#endif

#endif

